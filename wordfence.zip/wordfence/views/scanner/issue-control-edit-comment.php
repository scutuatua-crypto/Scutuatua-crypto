<?php
if (!defined('WORDFENCE_VERSION')) { exit; }
?>
<a href="${data.editCommentLink}" class="wf-issue-control wf-issue-control-edit-comment"><svg class="wf-issue-control-icon" viewBox="0 0 20 20"><rect x="0" fill="none" width="20" height="20"/><g><path d="M5 2h9c1.1 0 2 .9 2 2v7c0 1.1-.9 2-2 2h-2l-5 5v-5H5c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2z"/></g></svg><span class="wf-issue-control-label"><?php esc_html_e('Edit', 'wordfence'); ?></span></a>